var searchData=
[
  ['newgame',['newGame',['../main_8cpp.html#a9a4949ebfcb068b6bd82adc872ecd98c',1,'main.cpp']]],
  ['newplyr',['newPlyr',['../main_8cpp.html#a08c6e2caae7d9cba961b1ee3d9ca7aed',1,'main.cpp']]]
];
