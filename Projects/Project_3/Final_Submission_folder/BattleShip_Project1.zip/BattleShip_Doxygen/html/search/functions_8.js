var searchData=
[
  ['savgame',['savGame',['../main_8cpp.html#a768afd6b8cde69b4e76b129b9bf9d8fa',1,'main.cpp']]],
  ['setgame',['setGame',['../main_8cpp.html#a1874d5d838b4a584a8cead11d55aab95',1,'main.cpp']]]
];
