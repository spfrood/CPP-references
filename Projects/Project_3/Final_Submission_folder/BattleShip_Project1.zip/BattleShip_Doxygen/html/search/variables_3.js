var searchData=
[
  ['rows',['ROWS',['../struct_player.html#a05e8513ffc24371b5c242ef17b5cfba1',1,'Player']]]
];
