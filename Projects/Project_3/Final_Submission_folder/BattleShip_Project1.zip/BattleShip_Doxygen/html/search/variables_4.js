var searchData=
[
  ['ship',['ship',['../struct_player.html#acee20c03cd87a5596defc5bf0f1bd77e',1,'Player']]]
];
