var searchData=
[
  ['clrdata',['clrData',['../main_8cpp.html#a2af84db2c7f539ef6307d52aac0f7866',1,'main.cpp']]],
  ['comgues',['comGues',['../main_8cpp.html#a88a16b40c5ecf950f382ee0499d88758',1,'main.cpp']]]
];
