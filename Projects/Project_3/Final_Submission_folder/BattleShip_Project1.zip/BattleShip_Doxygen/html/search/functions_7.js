var searchData=
[
  ['rescomp',['resComp',['../main_8cpp.html#aac4aeee3e0e7edfe44a6a167c807d944',1,'main.cpp']]],
  ['resgame',['resGame',['../main_8cpp.html#abfb284bcf1d029b7ece854bc7d4940ae',1,'main.cpp']]],
  ['reshum',['resHum',['../main_8cpp.html#a2fadc632e184ffc2e88e5d3c2d4baee1',1,'main.cpp']]],
  ['rngfind',['rngFind',['../main_8cpp.html#ab56884b810c5cbab600dff512c5a2d2b',1,'main.cpp']]]
];
