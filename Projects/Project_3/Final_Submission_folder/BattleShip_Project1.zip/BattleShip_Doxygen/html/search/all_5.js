var searchData=
[
  ['hits',['hits',['../struct_player.html#a052222bcdb49688a6a4afa2687498db4',1,'Player']]]
];
