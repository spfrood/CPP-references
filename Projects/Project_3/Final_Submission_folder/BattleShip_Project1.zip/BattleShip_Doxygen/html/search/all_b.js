var searchData=
[
  ['red',['RED',['../colors_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'colors.h']]],
  ['rescomp',['resComp',['../main_8cpp.html#aac4aeee3e0e7edfe44a6a167c807d944',1,'main.cpp']]],
  ['reset',['RESET',['../colors_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'colors.h']]],
  ['resgame',['resGame',['../main_8cpp.html#abfb284bcf1d029b7ece854bc7d4940ae',1,'main.cpp']]],
  ['reshum',['resHum',['../main_8cpp.html#a2fadc632e184ffc2e88e5d3c2d4baee1',1,'main.cpp']]],
  ['rngfind',['rngFind',['../main_8cpp.html#ab56884b810c5cbab600dff512c5a2d2b',1,'main.cpp']]],
  ['rows',['ROWS',['../struct_player.html#a05e8513ffc24371b5c242ef17b5cfba1',1,'Player']]]
];
