var searchData=
[
  ['green',['GREEN',['../colors_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'colors.h']]],
  ['guess',['guess',['../struct_player.html#ab0219b4a6d9affb21471836b70939a56',1,'Player']]],
  ['guesses',['guesses',['../struct_player.html#aa786f3096665b656ab564841a75ffebd',1,'Player']]]
];
