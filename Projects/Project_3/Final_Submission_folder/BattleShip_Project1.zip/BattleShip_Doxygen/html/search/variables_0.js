var searchData=
[
  ['cols',['COLS',['../struct_player.html#add95189ad02241243a45d93dc3b793f2',1,'Player::COLS()'],['../main_8cpp.html#abfdc2552f8ab882b4380b2a56cdff54f',1,'COLS():&#160;main.cpp']]]
];
