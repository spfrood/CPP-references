

/* 
 * File:   Pstats.h
 * Author: scott_r_parker
 *
 * Created on March 25, 2017, 10:41 PM
 */

#ifndef PSTATS_H
#define PSTATS_H

struct Pstats {
    string name;
    int number;
    int points;
};

#endif /* PSTATS_H */

