
/* 
 * File:   divData.h
 * Author: scott_r_parker
 *
 * Created on March 25, 2017, 2:33 PM
 */

#ifndef DIVDATA_H
#define DIVDATA_H

struct DivData {
    string divName;
    int qOneSal;
    int qTwoSal;
    int qThrSal;
    int qFouSal;
    int totSale;
    float avgSale;
};


#endif /* DIVDATA_H */

