

/* 
 * File:   Speaker.h
 * Author: scott_r_parker
 *
 * Created on March 26, 2017, 10:47 AM
 */

#ifndef SPEAKER_H
#define SPEAKER_H

struct Speaker {
    int spkrNum;
    string name;
    string telNum;
    string topic;
    int minFee;
};


#endif /* SPEAKER_H */

