/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TxtNum.h
 * Author: rcc
 *
 * Created on May 8, 2017, 11:13 AM
 */

#ifndef TXTNUM_H
#define TXTNUM_H

#include <iostream>
#include <string>
using namespace std;

class TxtNum {
private:    
    int number;
public:
    TxtNum();
    virtual ~TxtNum();
    
    
};

#endif /* TXTNUM_H */

