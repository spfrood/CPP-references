/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TxtNum.cpp
 * Author: rcc
 * 
 * Created on May 8, 2017, 11:13 AM
 */

#include "TxtNum.h"

TxtNum::TxtNum() {
}

TxtNum::~TxtNum() {
}

