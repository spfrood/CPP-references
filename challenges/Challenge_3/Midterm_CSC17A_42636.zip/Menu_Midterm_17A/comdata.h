/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   comdata.h
 * Author: scott_r_parker
 *
 * Created on April 22, 2017, 12:09 PM
 */

#ifndef COMDATA_H
#define COMDATA_H

struct ComData {
    string comName;
    string street;
    string city;
    string state;
    string zip;
    string date;
    
};

#endif /* COMDATA_H */

