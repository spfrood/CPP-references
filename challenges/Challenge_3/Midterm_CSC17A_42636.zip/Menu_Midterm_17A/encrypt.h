/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   encrypt.h
 * Author: scott_r_parker
 *
 * Created on April 23, 2017, 8:33 PM
 */

#ifndef ENCRYPT_H
#define ENCRYPT_H

struct Encrypt {
    short dig1;
    short dig2;
    short dig3;
    short dig4;
};

#endif /* ENCRYPT_H */

