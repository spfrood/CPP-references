/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   empdata.h
 * Author: scott_r_parker
 *
 * Created on April 22, 2017, 12:08 PM
 */

#ifndef EMPDATA_H
#define EMPDATA_H
struct EmpData {
    string empName;
    short hrsWrkd;
    short payRate;
};


#endif /* EMPDATA_H */

